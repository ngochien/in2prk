package de.hawhamburg.se;

public enum CreditCardType {
	CREDIT, DEBIT
}
