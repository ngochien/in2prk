-- Verbindet sich als ein bestimmter Benutzer.
--
-- Globale Variablen:
-- &target_sys: Zielsystem
--
-- Parameter:
-- &1: Name des Benutzers.
-- &2: Passwort des Benutzer

connect &1/&2@&target_sys


